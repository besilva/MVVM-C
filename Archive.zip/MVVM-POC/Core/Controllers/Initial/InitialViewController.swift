//
//  InitialViewController.swift
//  MVVM-POC
//
//  Created by Bernardo Silva on 02/04/20.
//  Copyright © 2020 Bernardo. All rights reserved.
//

import UIKit

class InitialViewController: UIViewController, Storyboarded {
    
    var viewModel: InitialViewModel?
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    @IBAction func charactersButtonTapped(_ sender: Any) {
        viewModel?.goToCharacters()
    }
    
    @IBAction func episodesButtonTapped(_ sender: Any) {
        viewModel?.goToEpisodes()
    }
    @IBAction func locationsButtonPressed(_ sender: Any) {
//        viewModel?.goToLocations()
        let detail = DetailViewController.instantiate()
        detail.viewModel = DetailViewModel(id: 1, name: "teste", appearences: [], url: "teste", created: "teste2")
        self.present(detail, animated: true, completion: {print("Apresentou")})
    }
}
